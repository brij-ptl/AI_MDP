"use client";

import { useEffect, useState } from "react";
import { adminService } from "@/services/admin.service";
import { BrainCircuit, ShieldAlert, Search } from "lucide-react";

export default function ModelsAdminPage() {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const loadReports = async () => {
    try {
      setLoading(true);
      setError(null);
      const res: any = await adminService.accuracyReports();
      if (res && res.data) {
        setReports(res.data);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load model reports");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, []);

  const filteredReports = reports.filter((r) => 
    r.model_name?.toLowerCase().includes(search.toLowerCase()) ||
    r.disease?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="animate-fadeIn">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">AI Models & Accuracy</h1>
          <p className="mt-1 text-sm text-muted">Monitor diagnostic AI models, view confusion matrices and classification reports.</p>
        </div>
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            placeholder="Search models..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-border bg-surface2 py-2.5 pl-10 pr-4 text-sm outline-none transition-colors focus:border-primary"
          />
          <Search size={16} className="absolute left-3 top-3 text-muted" />
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-surface shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-surface2 text-muted">
              <tr>
                <th className="whitespace-nowrap px-6 py-4 font-medium">Model / Disease</th>
                <th className="whitespace-nowrap px-6 py-4 font-medium">Algorithm</th>
                <th className="whitespace-nowrap px-6 py-4 font-medium">Accuracy</th>
                <th className="whitespace-nowrap px-6 py-4 font-medium">Precision / Recall</th>
                <th className="whitespace-nowrap px-6 py-4 font-medium text-right">Last Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-muted">
                    <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                    <p className="mt-2">Loading model data...</p>
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-coral">
                    <ShieldAlert size={24} className="mx-auto mb-2 opacity-50" />
                    <p>{error}</p>
                  </td>
                </tr>
              ) : filteredReports.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-muted">
                    <BrainCircuit size={24} className="mx-auto mb-2 opacity-50" />
                    <p>No model reports found.</p>
                  </td>
                </tr>
              ) : (
                filteredReports.map((report, idx) => (
                  <tr key={idx} className="hover-card hover:bg-surface2 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-text capitalize">{report.disease}</div>
                      <div className="text-xs text-muted">{report.model_name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-block rounded bg-surface2 px-2 py-1 text-xs font-mono uppercase tracking-wider text-muted border border-border">
                        {report.algorithm || "Ensemble"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-mono font-bold text-teal">
                        {report.accuracy ? (report.accuracy * 100).toFixed(1) + "%" : "N/A"}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-xs">
                        <span className="text-muted">P:</span> {report.precision ? (report.precision * 100).toFixed(1) + "%" : "-"}
                        <span className="mx-2 text-border">|</span>
                        <span className="text-muted">R:</span> {report.recall ? (report.recall * 100).toFixed(1) + "%" : "-"}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right whitespace-nowrap text-muted text-xs">
                      {report.updated_at ? new Date(report.updated_at).toLocaleDateString() : "Unknown"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
